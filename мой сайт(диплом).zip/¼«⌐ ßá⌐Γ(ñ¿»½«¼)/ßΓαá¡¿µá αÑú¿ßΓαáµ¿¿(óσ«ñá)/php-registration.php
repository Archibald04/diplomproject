<?php
// Параметры подключения к базе данных
$servername = "localhost"; // Имя сервера базы данных (обычно localhost)
$username = "Имя пользователя"; // Имя пользователя базы данных
$password = "password"; // Пароль пользователя базы данных
$dbname = "данные"; // Имя базы данных

// Создание подключения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>

