<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $quantity = $_POST['quantity'];
    $details = $_POST['details'];

    $to = 'artur22knol@mail.ru';
    $subject = 'Заказ визиток/наклеек';
    $message = "Имя: $name\nEmail: $email\nТелефон: $phone\nКоличество: $quantity\nДополнительные детали: $details";
    $headers = "From: $email";

    if (mail($to, $subject, $message, $headers)) {
        echo '<p>Ваш заказ успешно отправлен.</p>';
    } else {
        echo '<p>Что-то пошло не так. Пожалуйста, попробуйте еще раз.</p>';
    }
}
?>
